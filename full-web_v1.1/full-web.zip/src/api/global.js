import Vue from 'vue'
import axios from 'axios'
import Qs from 'qs'

export default{
  //登录接口
  login:function(data){
    return axios({
      headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'},
      timeout: 3000,
      method: 'post',
      url:'/api/login',
      data: Qs.stringify(data)

    });
  }

  //
}
