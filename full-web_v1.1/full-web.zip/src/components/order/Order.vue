<template>
  <section>
    <!--工具条-->
		<el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
			<el-form :inline="true" ><!--输入框长度-->
				<el-form-item>
					<el-input  placeholder="订单号"></el-input>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" >查询</el-button>
				</el-form-item>
        <!-- <el-form-item>
					<el-button type="primary" @click="handleAdd">新增</el-button>
				</el-form-item> -->

			</el-form>
		</el-col>

    <!--列表-->
		<el-table style="width: 100%;">
			<el-table-column type="selection" width="55">
			</el-table-column>
			<el-table-column type="index" width="60">
			</el-table-column>
			<el-table-column prop="orderId" label="订单号" width="120" sortable>
			</el-table-column>
			<el-table-column prop="tableId" label="餐桌号" width="100" sortable>
			</el-table-column>
			<el-table-column prop="oderPrice" label="订单金额" width="120" sortable>
			</el-table-column>
			<el-table-column prop="payStatus" label="支付状态" width="120" sortable>
			</el-table-column>
			<el-table-column prop="orderCreatetime" label="时间" min-width="180" sortable>
			</el-table-column>
			<el-table-column label="操作" width="150">
          <template>
            <!-- 操作按钮 加点击事件-->
              <el-button></el-button>
          </template>
			</el-table-column>
		</el-table>
  </section>
</template>

<script>
  export default{

  }
</script>

<style>

</style>
