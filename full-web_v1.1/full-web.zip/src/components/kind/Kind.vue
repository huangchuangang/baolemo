<template>
  <div>
  kind
  </div>
</template>

<script>
  export default{

  }
</script>

<style>

</style>
